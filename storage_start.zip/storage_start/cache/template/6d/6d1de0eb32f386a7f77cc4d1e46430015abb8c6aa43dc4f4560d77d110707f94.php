<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/template/checkout/payment_method.twig */
class __TwigTemplate_d867a5a580862fd68479ba6a8b611517928d7faa16b5a6f633329d91f2140d57 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if (($context["error_warning"] ?? null)) {
            // line 2
            echo "<div class=\"alert alert-warning alert-dismissible\"><i class=\"fa fa-exclamation-circle\"></i> ";
            echo ($context["error_warning"] ?? null);
            echo "</div>
";
        }
        // line 4
        if (($context["payment_methods"] ?? null)) {
            // line 5
            echo "<h3>";
            echo ($context["text_payment_method"] ?? null);
            echo "</h3>
";
            // line 6
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["payment_methods"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["payment_method"]) {
                // line 7
                echo "<div class=\"p-radio\">
  <label>";
                // line 8
                if (((twig_get_attribute($this->env, $this->source, $context["payment_method"], "code", [], "any", false, false, false, 8) == ($context["code"] ?? null)) ||  !($context["code"] ?? null))) {
                    // line 9
                    echo "    ";
                    $context["code"] = twig_get_attribute($this->env, $this->source, $context["payment_method"], "code", [], "any", false, false, false, 9);
                    // line 10
                    echo "    <input type=\"radio\" name=\"payment_method\" value=\"";
                    echo twig_get_attribute($this->env, $this->source, $context["payment_method"], "code", [], "any", false, false, false, 10);
                    echo "\" checked=\"checked\" />
      <div class=\"check\"></div>
    ";
                } else {
                    // line 13
                    echo "    <input type=\"radio\" name=\"payment_method\" value=\"";
                    echo twig_get_attribute($this->env, $this->source, $context["payment_method"], "code", [], "any", false, false, false, 13);
                    echo "\" />
      <div class=\"check\"></div>
    ";
                }
                // line 16
                echo "    ";
                echo twig_get_attribute($this->env, $this->source, $context["payment_method"], "title", [], "any", false, false, false, 16);
                echo "
    ";
                // line 17
                if (twig_get_attribute($this->env, $this->source, $context["payment_method"], "terms", [], "any", false, false, false, 17)) {
                    // line 18
                    echo "    (";
                    echo twig_get_attribute($this->env, $this->source, $context["payment_method"], "terms", [], "any", false, false, false, 18);
                    echo ")
    ";
                }
                // line 19
                echo " </label>
</div>
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['payment_method'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 23
        echo "<p><h4>";
        echo ($context["text_comments"] ?? null);
        echo "</h4></p>
<p>
  <textarea name=\"comment\" rows=\"8\" class=\"form-control\">";
        // line 25
        echo ($context["comment"] ?? null);
        echo "</textarea>
</p>
";
        // line 27
        if (($context["text_agree"] ?? null)) {
            // line 28
            echo "<div class=\"buttons\">
  ";
            // line 29
            echo ($context["text_agree"] ?? null);
            echo "
  <div class=\"pull-right\" style=\"margin-right: 1em\">
    <div class=\"squaredTwo\">
    ";
            // line 32
            if (($context["agree"] ?? null)) {
                // line 33
                echo "    <input type=\"checkbox\" name=\"agree\" id=\"agree\" value=\"1\" checked=\"checked\" />
      <label for=\"agree\"></label>
    ";
            } else {
                // line 36
                echo "    <input type=\"checkbox\" name=\"agree\" id=\"agree\" value=\"1\" checked=\"checked\" />
      <label for=\"agree\"></label>
    ";
            }
            // line 39
            echo "    &nbsp;</div>
    <br>
    <input type=\"button\" value=\"";
            // line 41
            echo ($context["button_continue"] ?? null);
            echo "\" id=\"button-payment-method\" data-loading-text=\"";
            echo ($context["text_loading"] ?? null);
            echo "\" class=\"add\" style=\"width: 10em !important;\" />
  </div>
</div>
";
        } else {
            // line 45
            echo "<div class=\"buttons\">
  <div class=\"pull-right\">
    <input type=\"button\" value=\"";
            // line 47
            echo ($context["button_continue"] ?? null);
            echo "\" id=\"button-payment-method\" data-loading-text=\"";
            echo ($context["text_loading"] ?? null);
            echo "\" class=\"btn btn-primary\" />
  </div>
</div>
";
        }
        // line 50
        echo " ";
    }

    public function getTemplateName()
    {
        return "default/template/checkout/payment_method.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 50,  151 => 47,  147 => 45,  138 => 41,  134 => 39,  129 => 36,  124 => 33,  122 => 32,  116 => 29,  113 => 28,  111 => 27,  106 => 25,  100 => 23,  91 => 19,  85 => 18,  83 => 17,  78 => 16,  71 => 13,  64 => 10,  61 => 9,  59 => 8,  56 => 7,  52 => 6,  47 => 5,  45 => 4,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "default/template/checkout/payment_method.twig", "");
    }
}
